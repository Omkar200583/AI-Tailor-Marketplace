import asyncio
import io
import logging
import shutil
from pathlib import Path

from gradio_client import Client, handle_file
from PIL import Image

from app.core.config import get_settings
from app.core.exceptions import UpstreamError

log = logging.getLogger(__name__)


def _run_sync(person_path: str, garment_path: str, description: str) -> bytes:
    """
    Calls a hosted Gradio Space (default: IDM-VTON). Segmentation/parsing is done inside the model pipeline.
    NOTE: Space API signatures can change. Check with:
        python -c "from gradio_client import Client; Client('yisol/IDM-VTON').view_api()"
    """
    s = get_settings()
    try:
        client = Client(s.tryon_space, hf_token=s.hf_token or None)
        result = client.predict(
            dict={"background": handle_file(person_path), "layers": [], "composite": None},
            garm_img=handle_file(garment_path),
            garment_des=description,
            is_checked=True,
            is_checked_crop=False,
            denoise_steps=30,
            seed=42,
            api_name=s.tryon_api_name,
        )
        out_path = result[0] if isinstance(result, (list, tuple)) else result
        img = Image.open(out_path).convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return buf.getvalue()
    except Exception as exc:
        raise UpstreamError(f"Virtual try-on failed (Space busy, quota used or API changed): {exc}") from exc
    finally:
        shutil.rmtree(Path(person_path).parent, ignore_errors=True)


async def run_tryon(person_path: str, garment_path: str, description: str = "clothing") -> bytes:
    return await asyncio.to_thread(_run_sync, person_path, garment_path, description)
