import random

from app.services import huggingface_service


async def generate_image(prompt: str) -> bytes:
    return await huggingface_service.text_to_image(prompt, seed=random.randint(0, 2**31 - 1))
