import asyncio

import cloudinary
import cloudinary.uploader

from app.core.config import get_settings
from app.core.exceptions import ConfigError, UpstreamError


def _configure() -> None:
    s = get_settings()
    if not (s.cloudinary_cloud_name and s.cloudinary_api_key and s.cloudinary_api_secret):
        raise ConfigError("Cloudinary credentials are missing in .env")
    cloudinary.config(
        cloud_name=s.cloudinary_cloud_name,
        api_key=s.cloudinary_api_key,
        api_secret=s.cloudinary_api_secret,
        secure=True,
    )


def _upload_sync(data: bytes, folder: str, public_id: str | None) -> dict:
    _configure()
    try:
        return cloudinary.uploader.upload(
            data, folder=folder, public_id=public_id, resource_type="image", overwrite=True
        )
    except Exception as exc:  # cloudinary raises generic errors
        raise UpstreamError(f"Cloudinary upload failed: {exc}") from exc


async def upload_image(data: bytes, folder: str, public_id: str | None = None) -> dict:
    result = await asyncio.to_thread(_upload_sync, data, folder, public_id)
    return {"url": result["secure_url"], "public_id": result["public_id"]}
